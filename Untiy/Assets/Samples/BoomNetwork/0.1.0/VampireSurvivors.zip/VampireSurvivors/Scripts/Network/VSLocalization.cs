// BoomNetwork VampireSurvivors Demo — Simple EN/ZH Localization
// Auto-detects system language. Call Toggle() for manual override.

using UnityEngine;

namespace BoomNetwork.Samples.VampireSurvivors
{
    public static class VSLocalization
    {
        public enum Str
        {
            Title, Host, Port, Connect, Connecting, Connected,
            JoinedRoom, RoomReady, Disconnected,
            Wave, EnemyCount, Bandwidth, Dead, Choosing,
            LevelUpTitle, Paused, Desync,
            WeaponNew, WeaponUpgrade,
            KnifeName, OrbName, LightningName, HolyWaterName,
            LangToggle,
        }

        // [0] = EN, [1] = ZH
        static readonly string[][] _table =
        {
            /* Title */        new[] { "Vampire Survivors",                              "吸血鬼幸存者" },
            /* Host */         new[] { "Host",                                           "主机" },
            /* Port */         new[] { "Port",                                           "端口" },
            /* Connect */      new[] { "CONNECT",                                        "连接" },
            /* Connecting */   new[] { "Connecting to {0}:{1}...",                       "正在连接 {0}:{1}..." },
            /* Connected */    new[] { "Connected \u2014 joining room...",               "已连接，加入房间..." },
            /* JoinedRoom */   new[] { "Joined room {0} ({1} players)",                  "已加入房间 {0}（{1} 名玩家）" },
            /* RoomReady */    new[] { "Room ready \u2014 starting...",                  "房间就绪，游戏开始..." },
            /* Disconnected */ new[] { "Disconnected",                                   "已断开连接" },
            /* Wave */         new[] { "Wave {0}",                                       "第 {0} 波" },
            /* EnemyCount */   new[] { "Enemies: {0}/{1}",                               "敌人: {0}/{1}" },
            /* Bandwidth */    new[] { "{0} enemies \u00b7 0 extra bandwidth (FrameSync)", "{0} 个敌人 · 零额外带宽（帧同步）" },
            /* Dead */         new[] { "DEAD",                                           "阵亡" },
            /* Choosing */     new[] { " [CHOOSING...]",                                 " [选择中...]" },
            /* LevelUpTitle */ new[] { "LEVEL UP! (Lv.{0})  Choose upgrade:",           "升级！（等级 {0}）选择强化：" },
            /* Paused */       new[] { "PAUSED\nP{0} is choosing an upgrade...",         "暂停中\nP{0} 正在选择升级..." },
            /* Desync */       new[] { "DESYNC DETECTED\nFrame {0} \u2014 hashes differ. Game paused.",
                                        "检测到不同步\n第 {0} 帧哈希不一致，游戏已暂停。" },
            /* WeaponNew */    new[] { "[{0}] {1} {2} (NEW)",                            "[{0}] {1} {2}（新）" },
            /* WeaponUpgrade */ new[] { "[{0}] {1} {2} Lv{3} \u2192 Lv{4}",            "[{0}] {1} {2} Lv{3} → Lv{4}" },
            /* KnifeName */    new[] { "Knife",                                          "飞刀" },
            /* OrbName */      new[] { "Orb",                                            "法球" },
            /* LightningName */ new[] { "Lightning",                                     "闪电" },
            /* HolyWaterName */ new[] { "Holy Water",                                    "圣水" },
            /* LangToggle */   new[] { "\u4e2d\u6587", "EN" }, // shows what you switch TO: EN→"中文", ZH→"EN"
        };

        static bool _useChinese;
        static bool _initialized;

        public static bool UseChinese
        {
            get
            {
                if (!_initialized)
                {
                    _initialized = true;
                    var lang = Application.systemLanguage;
                    _useChinese = lang == SystemLanguage.Chinese
                               || lang == SystemLanguage.ChineseSimplified
                               || lang == SystemLanguage.ChineseTraditional;
                }
                return _useChinese;
            }
        }

        public static void Toggle()
        {
            _ = UseChinese; // ensure initialized
            _useChinese = !_useChinese;
        }

        public static string Get(Str id)         => _table[(int)id][UseChinese ? 1 : 0];
        public static string Format(Str id, params object[] args) => string.Format(Get(id), args);
    }
}
