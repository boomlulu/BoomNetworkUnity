// BoomNetwork VampireSurvivors Demo — Network Manager
//
// DESIGN PRINCIPLE 1 — Deterministic paths (GameState mutation):
//   All GameState mutations go through exactly two paths driven by FrameData:
//   1. Frame events (OnPlayerJoined/Left) — embedded in FrameData,
//      dispatched BEFORE OnFrame, same frame on all clients.
//   2. OnFrame → Tick → ApplyInputs — processes player inputs,
//      auto-inits players on first input appearance.
//   OnFrameSyncStart only sets up the deterministic seed and Dt.
//   No InitPlayer, no direct GameState mutation outside frame processing.
//
// DESIGN PRINCIPLE 2 — Level-Triggered Pause Convergence:
//   Game-pause state is managed via Level-Triggered State Convergence,
//   NOT edge-triggered delta tracking. On every OnFrame, we compare:
//     - wantsPause (game logic: IsAnyPlayerUpgrading)
//     - isPaused   (network state: IsGamePaused)
//   and drive toward convergence. This pattern is self-correcting and
//   handles same-tick consecutive state changes without any local memory.
//   The Update() path provides the deadlock-breaker (RequestGameResume)
//   for when the server is paused and OnFrame never fires.

using UnityEngine;
using BoomNetwork.Client.FrameSync;
using BoomNetwork.Core.FrameSync;
using BoomNetwork.Unity;

namespace BoomNetwork.Samples.VampireSurvivors
{
    [RequireComponent(typeof(BoomNetworkManager))]
    public class VSNetworkManager : MonoBehaviour
    {
        BoomNetworkManager _network;
        VSSimulation _sim;
        VSRenderer _renderer;
        VSUIManager _ui;

        readonly byte[] _inputBuf = new byte[VSInput.InputSize];
        float _sendTimer;
        int _localSlot = -1;
        bool _syncing;
        bool _snapshotLoaded;
        bool _desyncDetected;
        uint _desyncFrame;
        byte _pendingUpgradeChoice;
        bool _firstInputSent;

        // Mobile virtual joystick — null on PC/Editor
        VSVirtualJoystick _joystick;

        void Start()
        {
            _sim = new VSSimulation();
            _network = GetComponent<BoomNetworkManager>();
            var c = _network.Client;

            c.OnFrameSyncStart  += OnFrameSyncStart;
            c.OnFrameSyncStop   += OnFrameSyncStop;
            c.OnFrame           += OnFrame;
            c.OnConnected       += OnNetworkConnected;
            c.OnReady           += OnNetworkReady;
            c.OnJoinedRoom      += OnJoinedRoom;
            c.OnPlayerJoined    += OnPlayerJoined;
            c.OnPlayerLeft      += OnPlayerLeft;
            c.OnTakeSnapshot     = TakeSnapshot;
            c.OnLoadSnapshot     = LoadSnapshot;
            c.OnDesyncDetected  += OnDesync;

            _ui = VSUIManager.Create(gameObject);
            _ui.OnUpgradeChosen  += choice => _pendingUpgradeChoice = choice;
            _ui.OnConnectClicked += OnConnectClicked;
            _ui.ShowConnectPanel(true);
        }

        // ── Connect button handler ─────────────────────────────────────────────

        void OnConnectClicked(string host, int port)
        {
            _ui.SetStatus(VSLocalization.Format(VSLocalization.Str.Connecting, host, port));
            _network.Connect(host, port);
        }

        // ── Update ────────────────────────────────────────────────────────────

        void Update()
        {
            if (_syncing && _ui != null)
            {
                _ui.UpdateHUD(_sim.State, _localSlot, Mathf.RoundToInt(_network.Client.RttMs));
                UpdateBarsForLocalPlayer();
                UpdateOverlays();
            }

            if (!_syncing) return;

            // Upgrade key presses (keyboard fallback for PC)
            if (_localSlot >= 0 && _localSlot < GameState.MaxPlayers
                && _sim.State.Players[_localSlot].PendingLevelUp)
            {
                if (Input.GetKeyDown(KeyCode.Alpha1)) _pendingUpgradeChoice = 1;
                if (Input.GetKeyDown(KeyCode.Alpha2)) _pendingUpgradeChoice = 2;
                if (Input.GetKeyDown(KeyCode.Alpha3)) _pendingUpgradeChoice = 4;
                if (Input.GetKeyDown(KeyCode.Alpha4)) _pendingUpgradeChoice = 8;
            }

            _sendTimer += Time.deltaTime * 1000f;
            if (_sendTimer < 50f) return;
            _sendTimer -= 50f;

            // Unified input: joystick OR keyboard, joystick takes priority when active.
            // Keyboard always available as fallback (PC + mobile with physical keyboard).
            float jx = _joystick != null ? _joystick.Direction.x : 0f;
            float jy = _joystick != null ? _joystick.Direction.y : 0f;
            bool joystickActive = jx != 0f || jy != 0f;
            float h = joystickActive ? jx : Input.GetAxisRaw("Horizontal");
            float v = joystickActive ? jy : Input.GetAxisRaw("Vertical");
            byte ability = _pendingUpgradeChoice;
            _pendingUpgradeChoice = 0;

            // First input must always be sent to trigger auto-init in ApplyInputs.
            // "Silent When Idle" would otherwise delay player spawn indefinitely.
            if (!_firstInputSent)
            {
                _firstInputSent = true;
                VSInput.Encode(_inputBuf, h, v, ability);
                _network.SendInput(_inputBuf);
                return;
            }

            if (h == 0f && v == 0f && ability == 0) return;
            VSInput.Encode(_inputBuf, h, v, ability);
            _network.SendInput(_inputBuf);

            // Deadlock-breaker: while server is paused, OnFrame never fires.
            // RequestGameResume unblocks frame delivery after upgrade choice is sent.
            if (ability != 0)
            {
                Debug.Log($"[VS] Upgrade choice sent: ability={ability}, IsGamePaused={_network.Client.IsGamePaused}");
                _network.Client.RequestGameResume();
            }
        }

        void UpdateBarsForLocalPlayer()
        {
            if (_localSlot < 0 || _localSlot >= GameState.MaxPlayers) return;
            ref var p = ref _sim.State.Players[_localSlot];
            if (!p.IsActive) { _ui.HideBars(); return; }
            _ui.UpdateBars(p.Hp, p.MaxHp, p.Xp, p.XpToNextLevel, p.Level);
        }

        void UpdateOverlays()
        {
            bool localUpgrading = _localSlot >= 0 && _localSlot < GameState.MaxPlayers
                && _sim.State.Players[_localSlot].PendingLevelUp;

            if (localUpgrading)
            {
                _ui.ShowUpgrade(true);
                _ui.UpdateUpgradePanel(ref _sim.State.Players[_localSlot]);
            }
            else
            {
                _ui.ShowUpgrade(false);
            }

            // Pause overlay: another player is upgrading
            int upgradingSlot = -1;
            if (!localUpgrading)
            {
                for (int i = 0; i < GameState.MaxPlayers; i++)
                {
                    if (_sim.State.Players[i].IsActive && _sim.State.Players[i].PendingLevelUp)
                    { upgradingSlot = i; break; }
                }
            }
            _ui.ShowPause(upgradingSlot >= 0, upgradingSlot);
        }

        // ==================== Network Events ====================

        void OnNetworkConnected()
        {
            _ui?.SetStatus(VSLocalization.Get(VSLocalization.Str.Connected));
            _network.Client.MatchRoom(4, null);
        }

        void OnNetworkReady()
        {
            _ui?.SetStatus(VSLocalization.Get(VSLocalization.Str.RoomReady));
            _network.Client.RequestStart();
        }

        void OnFrameSyncStart(FrameSyncInitData init)
        {
            FInt dt = FInt.FromInt(init.FrameInterval) / FInt.FromInt(1000);
            uint seed = (uint)(init.StartTime & 0xFFFFFFFF);

            if (!_snapshotLoaded)
            {
                // Fresh start — Init sets Dt, RngState, wave timers.
                // NO InitPlayer here. Players are initialized through two
                // deterministic paths only:
                //   a) OnPlayerJoined frame event (joins during sync)
                //   b) ApplyInputs auto-init (first input in FrameData)
                _sim.Init(dt, seed);
            }
            else
            {
                // Late join — snapshot has the complete game state.
                // Only apply Dt from InitData (snapshot already has correct
                // RngState, wave state, and all active players).
                _sim.State.Dt = dt;
            }

            // Map our PlayerId to a local slot (0-3). PidToSlot assigns
            // slots deterministically in order of first appearance.
            _localSlot = _sim.PidToSlot(_network.PlayerId);
            _syncing = true;

            _renderer = GetComponent<VSRenderer>();
            if (_renderer == null) _renderer = gameObject.AddComponent<VSRenderer>();
            float frameIntervalSec = init.FrameInterval / 1000f;
            _renderer.Init(_sim.State, _localSlot, frameIntervalSec);

            // Create virtual joystick on mobile (no-op on PC/Editor)
            if (_joystick == null)
                _joystick = VSVirtualJoystick.Create();

            _ui?.ShowConnectPanel(false);
            _ui?.SetHudVisible(true);

            Debug.Log($"[VS] FrameSync started. Pid={_network.PlayerId}, Slot={_localSlot}, snapshot={_snapshotLoaded}, dt={dt}, fps={init.FrameRate}");
        }

        void OnFrameSyncStop()
        {
            _syncing = false;
            _ui?.SetHudVisible(false);
            _ui?.HideBars();
            _ui?.ShowConnectPanel(true);
            _ui?.SetStatus(VSLocalization.Get(VSLocalization.Str.Disconnected));
        }

        void OnJoinedRoom(int roomId, int[] existingPlayerIds)
        {
            _ui?.SetStatus(VSLocalization.Format(VSLocalization.Str.JoinedRoom, roomId, existingPlayerIds.Length + 1));
            Debug.Log($"[VS] Joined room {roomId}, {existingPlayerIds.Length} existing players");
        }

        /// <summary>
        /// Frame event — embedded in FrameData, all clients process at the same frame.
        /// During sync: deterministic. Before sync: ExtCmd, only used for tracking.
        /// </summary>
        void OnPlayerJoined(int pid)
        {
            int slot = _sim.PidToSlot(pid);
            if (slot < 0 || slot >= GameState.MaxPlayers) return;

            // During sync, frame events guarantee same-frame delivery.
            // InitPlayer here is deterministic — all clients execute at the same frame.
            if (_syncing && !_sim.State.Players[slot].IsActive)
                _sim.State.InitPlayer(slot);

            Debug.Log($"[VS] Player {pid} joined (slot {slot}){(_syncing ? " — initialized via frame event" : "")}");
        }

        void OnPlayerLeft(int pid)
        {
            int slot = _sim.PidToSlot(pid);
            if (slot < 0 || slot >= GameState.MaxPlayers) return;

            if (_syncing)
            {
                _sim.State.Players[slot].IsActive = false;
                _sim.State.Players[slot].IsAlive = false;
            }
        }

        void OnFrame(FrameData frame)
        {
            if (_desyncDetected) return;

            _sim.Tick(frame);
            if (_renderer != null) _renderer.SyncVisuals();

            uint hash = _sim.State.ComputeHash();
            _network.Client.SendFrameHash(frame.FrameNumber, hash);

            // Level-Triggered Pause Convergence (see DESIGN PRINCIPLE 2 at top of file):
            // Compare game's desired pause state vs network's actual pause state,
            // and drive toward convergence every frame. No local memory needed.
            // IsGamePaused is the authoritative source of truth for network state.
            bool wantsPause = _sim.IsAnyPlayerUpgrading();
            if (wantsPause && !_network.Client.IsGamePaused)
                _network.Client.RequestGamePause();
            else if (!wantsPause && _network.Client.IsGamePaused)
                _network.Client.RequestGameResume();
        }

        void OnDesync(FrameHashMismatch mismatch)
        {
            _desyncDetected = true;
            _desyncFrame = mismatch.FrameNumber;
            string detail = $"DESYNC at frame {mismatch.FrameNumber}:";
            foreach (var (pid, h) in mismatch.PlayerHashes)
                detail += $"\n  P{pid}: 0x{h:X8}";
            Debug.LogError($"[VS] {detail}");

            _ui?.ShowDesync(true, mismatch.FrameNumber);
        }

        // Only take snapshots after sync has started — the initial
        // RequestStart snapshot would capture uninitialized state
        // (before Init sets the RNG seed), causing late-join desync.
        byte[] TakeSnapshot() => _syncing ? VSSnapshot.Serialize(_sim) : null;

        void LoadSnapshot(byte[] data)
        {
            _snapshotLoaded = true;
            VSSnapshot.Deserialize(data, _sim);

            // No InitPlayer, no state mutation. The snapshot is the
            // complete authoritative state. Players who join after the
            // snapshot will be initialized via frame events or auto-init.

            if (_renderer != null) _renderer.SyncVisuals();
            Debug.Log($"[VS] Snapshot loaded. Frame={_sim.State.FrameNumber}, Wave={_sim.State.WaveNumber}");
        }
    }
}
