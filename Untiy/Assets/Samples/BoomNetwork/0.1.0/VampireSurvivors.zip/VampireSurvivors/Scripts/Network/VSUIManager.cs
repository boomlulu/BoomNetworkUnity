// BoomNetwork VampireSurvivors Demo — UGUI Manager
// Pure runtime UGUI construction — no Prefabs required.
// Canvas: ScreenSpaceOverlay, sortingOrder=10, ScaleWithScreenSize 1920×1080 match=0.5

using System;
using UnityEngine;
using UnityEngine.UI;

namespace BoomNetwork.Samples.VampireSurvivors
{
    public class VSUIManager : MonoBehaviour
    {
        // ── Connect panel ──────────────────────────────────────────────────────
        GameObject _connectPanel;
        InputField _hostInput;
        InputField _portInput;
        Text _statusText;
        // Stored refs for language refresh
        Text _titleText, _hostLabel, _portLabel, _connectBtnLabel, _langBtnLabel;

        // ── HP / XP bars (local player, top-center) ───────────────────────────
        GameObject _barsContainer;
        Image _hpFill;
        Text  _hpText;
        Image _xpFill;
        Text  _xpText;

        // ── HUD text (top-left) ────────────────────────────────────────────────
        GameObject _hudPanel;
        Text _hudText;

        // ── Desync overlay ─────────────────────────────────────────────────────
        GameObject _desyncPanel;
        Text _desyncText;

        // ── Pause overlay ──────────────────────────────────────────────────────
        GameObject _pausePanel;
        Text _pauseText;

        // ── Upgrade panel ──────────────────────────────────────────────────────
        GameObject _upgradePanel;
        Text _upgradeTitle;
        readonly Text[] _upgradeBtnTexts = new Text[4];

        Font _font;

        static readonly string[] WeaponIcons = { "", "\u2694", "\u2605", "\u26a1", "\u223c" };
        static readonly VSLocalization.Str[] WeaponLocKeys =
        {
            VSLocalization.Str.KnifeName,
            VSLocalization.Str.OrbName,
            VSLocalization.Str.LightningName,
            VSLocalization.Str.HolyWaterName,
        };

        /// <summary>Fired when the player clicks Connect. Args: (host, port).</summary>
        public event Action<string, int> OnConnectClicked;

        /// <summary>Fired when the player taps/clicks an upgrade button. Value is the ability bitmask (1 &lt;&lt; i).</summary>
        public event Action<byte> OnUpgradeChosen;

        // ── Factory ────────────────────────────────────────────────────────────

        public static VSUIManager Create(GameObject parent)
        {
            var canvasGo = new GameObject("VS_Canvas");
            canvasGo.transform.SetParent(parent.transform, false);

            var canvas = canvasGo.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 10;

            var scaler = canvasGo.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.matchWidthOrHeight = 0.5f;

            canvasGo.AddComponent<GraphicRaycaster>();

            var mgr = canvasGo.AddComponent<VSUIManager>();
            mgr.Build();
            return mgr;
        }

        // ── Build ──────────────────────────────────────────────────────────────

        void Build()
        {
            _font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");

            BuildConnectPanel();
            BuildBars();
            BuildHUD();
            BuildDesyncOverlay();
            BuildPauseOverlay();
            BuildUpgradePanel();
        }

        // Connect panel — center screen, 480×310
        void BuildConnectPanel()
        {
            _connectPanel = MakePanel(transform, new Color(0.05f, 0.05f, 0.10f, 0.95f),
                ancMin: new Vector2(0.5f, 0.5f), ancMax: new Vector2(0.5f, 0.5f),
                pivot:  new Vector2(0.5f, 0.5f),
                pos: Vector2.zero, size: new Vector2(480, 310));

            // Title (centered)
            _titleText = MakeText(_connectPanel.transform, 26, Color.white, TextAnchor.MiddleCenter);
            _titleText.text = VSLocalization.Get(VSLocalization.Str.Title);
            _titleText.fontStyle = FontStyle.Bold;
            SetRect(_titleText.GetComponent<RectTransform>(),
                new Vector2(0, 1), new Vector2(1, 1), new Vector2(0.5f, 1),
                new Vector2(0, -16), new Vector2(-90, 36));

            // Language toggle button (top-right of panel)
            var langBtn = MakeButton(_connectPanel.transform,
                new Vector2(388, -12), new Vector2(80, 30),
                () => { VSLocalization.Toggle(); RefreshLanguage(); });
            _langBtnLabel = langBtn.GetComponentInChildren<Text>();
            _langBtnLabel.fontSize = 16;
            _langBtnLabel.text = VSLocalization.Get(VSLocalization.Str.LangToggle);

            // Host row
            _hostLabel = MakeText(_connectPanel.transform, 18, Color.white, TextAnchor.MiddleLeft);
            _hostLabel.text = VSLocalization.Get(VSLocalization.Str.Host);
            SetRect(_hostLabel.GetComponent<RectTransform>(),
                new Vector2(0, 1), new Vector2(0, 1), new Vector2(0, 1),
                new Vector2(16, -72), new Vector2(60, 36));

            _hostInput = MakeInputField(_connectPanel.transform, "localhost", "localhost",
                new Vector2(82, -72), new Vector2(382, 36));

            // Port row
            _portLabel = MakeText(_connectPanel.transform, 18, Color.white, TextAnchor.MiddleLeft);
            _portLabel.text = VSLocalization.Get(VSLocalization.Str.Port);
            SetRect(_portLabel.GetComponent<RectTransform>(),
                new Vector2(0, 1), new Vector2(0, 1), new Vector2(0, 1),
                new Vector2(16, -116), new Vector2(60, 36));

            _portInput = MakeInputField(_connectPanel.transform, "9000", "9000",
                new Vector2(82, -116), new Vector2(382, 36));
            _portInput.contentType = InputField.ContentType.IntegerNumber;

            // Connect button
            var connectBtn = MakeButton(_connectPanel.transform,
                new Vector2(80, -170), new Vector2(320, 50),
                () =>
                {
                    string h = string.IsNullOrWhiteSpace(_hostInput.text) ? "localhost" : _hostInput.text.Trim();
                    int p = int.TryParse(_portInput.text, out int parsed) ? parsed : 9000;
                    OnConnectClicked?.Invoke(h, p);
                });
            _connectBtnLabel = connectBtn.GetComponentInChildren<Text>();
            _connectBtnLabel.text = VSLocalization.Get(VSLocalization.Str.Connect);

            // Status text
            _statusText = MakeText(_connectPanel.transform, 16, new Color(0.7f, 0.7f, 0.7f), TextAnchor.MiddleCenter);
            SetRect(_statusText.GetComponent<RectTransform>(),
                new Vector2(0, 1), new Vector2(1, 1), new Vector2(0.5f, 1),
                new Vector2(0, -240), new Vector2(-32, 60));
        }

        // HP/XP bars — top center, 768×64
        void BuildBars()
        {
            _barsContainer = MakePanel(transform, new Color(0, 0, 0, 0.60f),
                ancMin: new Vector2(0.5f, 1), ancMax: new Vector2(0.5f, 1),
                pivot:  new Vector2(0.5f, 1),
                pos: new Vector2(0, -10), size: new Vector2(768, 64));

            (_hpFill, _hpText) = BuildBar(_barsContainer.transform, -8,
                "HP", new Color(0.20f, 0.65f, 0.20f, 1f));
            (_xpFill, _xpText) = BuildBar(_barsContainer.transform, -36,
                "XP", new Color(0.25f, 0.45f, 0.90f, 1f));

            _barsContainer.SetActive(false);
        }

        (Image fill, Text valText) BuildBar(Transform parent, float yOffset, string label, Color fillColor)
        {
            const float labelW = 36f, barW = 530f, valW = 164f;
            const float barH = 22f;
            const float xLabel = 12f, xBar = 54f, xVal = 590f;

            var lbl = MakeText(parent, 16, Color.white, TextAnchor.MiddleLeft);
            lbl.text = label;
            SetRect(lbl.GetComponent<RectTransform>(),
                new Vector2(0, 1), new Vector2(0, 1), new Vector2(0, 1),
                new Vector2(xLabel, yOffset), new Vector2(labelW, barH));

            var bgGo = new GameObject("BarBG", typeof(RectTransform));
            bgGo.transform.SetParent(parent, false);
            SetRect(bgGo.GetComponent<RectTransform>(),
                new Vector2(0, 1), new Vector2(0, 1), new Vector2(0, 1),
                new Vector2(xBar, yOffset), new Vector2(barW, barH));
            var bgImg = bgGo.AddComponent<Image>();
            bgImg.color = new Color(0.12f, 0.12f, 0.12f, 1f);
            bgImg.sprite = WhiteSprite();

            var fillGo = new GameObject("Fill", typeof(RectTransform));
            fillGo.transform.SetParent(bgGo.transform, false);
            FillRect(fillGo.GetComponent<RectTransform>(), 0, 0);
            var fillImg = fillGo.AddComponent<Image>();
            fillImg.type       = Image.Type.Filled;
            fillImg.fillMethod = Image.FillMethod.Horizontal;
            fillImg.fillOrigin = 0;
            fillImg.fillAmount = 1f;
            fillImg.color      = fillColor;
            fillImg.sprite     = WhiteSprite();

            var valText = MakeText(parent, 15, Color.white, TextAnchor.MiddleLeft);
            SetRect(valText.GetComponent<RectTransform>(),
                new Vector2(0, 1), new Vector2(0, 1), new Vector2(0, 1),
                new Vector2(xVal, yOffset), new Vector2(valW, barH));

            return (fillImg, valText);
        }

        // HUD text — top-left, 460×220
        void BuildHUD()
        {
            _hudPanel = MakePanel(transform, new Color(0, 0, 0, 0.75f),
                ancMin: new Vector2(0, 1), ancMax: new Vector2(0, 1),
                pivot:  new Vector2(0, 1),
                pos: new Vector2(10, -10), size: new Vector2(460, 220));

            _hudText = MakeText(_hudPanel.transform, 18, Color.white, TextAnchor.UpperLeft);
            FillRect(_hudText.GetComponent<RectTransform>(), 10, 8);
            _hudPanel.SetActive(false);
        }

        void BuildDesyncOverlay()
        {
            _desyncPanel = MakePanel(transform, new Color(0, 0, 0, 0.88f),
                ancMin: new Vector2(0.5f, 0.5f), ancMax: new Vector2(0.5f, 0.5f),
                pivot:  new Vector2(0.5f, 0.5f),
                pos: new Vector2(0, 120), size: new Vector2(540, 100));

            _desyncText = MakeText(_desyncPanel.transform, 22, new Color(1f, 0.2f, 0.2f), TextAnchor.MiddleCenter);
            _desyncText.fontStyle = FontStyle.Bold;
            FillRect(_desyncText.GetComponent<RectTransform>(), 8, 8);
            _desyncPanel.SetActive(false);
        }

        void BuildPauseOverlay()
        {
            _pausePanel = MakePanel(transform, new Color(0, 0, 0, 0.80f),
                ancMin: new Vector2(0.5f, 0.5f), ancMax: new Vector2(0.5f, 0.5f),
                pivot:  new Vector2(0.5f, 0.5f),
                pos: new Vector2(0, -80), size: new Vector2(440, 80));

            _pauseText = MakeText(_pausePanel.transform, 22, new Color(1f, 1f, 0.3f), TextAnchor.MiddleCenter);
            _pauseText.fontStyle = FontStyle.Bold;
            FillRect(_pauseText.GetComponent<RectTransform>(), 8, 8);
            _pausePanel.SetActive(false);
        }

        void BuildUpgradePanel()
        {
            const float pw = 480f, ph = 430f;
            _upgradePanel = MakePanel(transform, new Color(0.05f, 0.05f, 0.12f, 0.94f),
                ancMin: new Vector2(0.5f, 0.5f), ancMax: new Vector2(0.5f, 0.5f),
                pivot:  new Vector2(0.5f, 0.5f),
                pos: Vector2.zero, size: new Vector2(pw, ph));

            _upgradeTitle = MakeText(_upgradePanel.transform, 22, new Color(1f, 0.9f, 0.1f), TextAnchor.UpperLeft);
            _upgradeTitle.fontStyle = FontStyle.Bold;
            SetRect(_upgradeTitle.GetComponent<RectTransform>(),
                new Vector2(0, 1), new Vector2(1, 1), new Vector2(0, 1),
                new Vector2(12, -12), new Vector2(-24, 40));

            for (int i = 0; i < 4; i++)
            {
                int idx = i;
                float btnY = -12f - 40f - 14f - idx * 90f;
                var btn = MakeButton(_upgradePanel.transform,
                    new Vector2(12, btnY), new Vector2(pw - 24, 80),
                    () => OnUpgradeChosen?.Invoke((byte)(1 << idx)));
                _upgradeBtnTexts[i] = btn.GetComponentInChildren<Text>();
            }
            _upgradePanel.SetActive(false);
        }

        // ── Public API ─────────────────────────────────────────────────────────

        public void ShowConnectPanel(bool show) => _connectPanel.SetActive(show);
        public void SetStatus(string msg)        => _statusText.text = msg;
        public void SetHudVisible(bool v)        => _hudPanel.SetActive(v);

        public void RefreshLanguage()
        {
            _titleText.text      = VSLocalization.Get(VSLocalization.Str.Title);
            _hostLabel.text      = VSLocalization.Get(VSLocalization.Str.Host);
            _portLabel.text      = VSLocalization.Get(VSLocalization.Str.Port);
            _connectBtnLabel.text = VSLocalization.Get(VSLocalization.Str.Connect);
            _langBtnLabel.text   = VSLocalization.Get(VSLocalization.Str.LangToggle);
        }

        public void UpdateBars(int hp, int maxHp, int xp, int xpToNext, int level)
        {
            _barsContainer.SetActive(true);
            _hpFill.fillAmount = maxHp > 0 ? Mathf.Clamp01((float)hp / maxHp) : 0f;
            _hpText.text = $"{hp} / {maxHp}";
            _xpFill.fillAmount = xpToNext > 0 ? Mathf.Clamp01((float)xp / xpToNext) : 0f;
            _xpText.text = $"Lv.{level}  {xp} / {xpToNext}";
        }

        public void HideBars() => _barsContainer.SetActive(false);

        public void UpdateHUD(GameState state, int localSlot, int rttMs)
        {
            int aliveEnemies = 0;
            for (int i = 0; i < GameState.MaxEnemies; i++)
                if (state.Enemies[i].IsAlive) aliveEnemies++;

            var sb = new System.Text.StringBuilder(256);
            sb.AppendLine($"<b>VS</b>  F:{state.FrameNumber}  RTT:{rttMs}ms");
            sb.AppendLine(VSLocalization.Format(VSLocalization.Str.Wave, state.WaveNumber) + "  " +
                          VSLocalization.Format(VSLocalization.Str.EnemyCount, aliveEnemies, GameState.MaxEnemies));

            for (int i = 0; i < GameState.MaxPlayers; i++)
            {
                ref var p = ref state.Players[i];
                if (!p.IsActive) continue;
                string me    = (i == localSlot) ? "\u2605 " : "  ";
                string alive = p.IsAlive ? "" : $" <color=red>{VSLocalization.Get(VSLocalization.Str.Dead)}</color>";
                string upg   = p.PendingLevelUp ? $"<color=yellow>{VSLocalization.Get(VSLocalization.Str.Choosing)}</color>" : "";
                string wpns  = BuildWeaponStr(ref p);
                sb.AppendLine($"{me}P{i + 1} Lv{p.Level} K:{p.KillCount} {wpns}{alive}{upg}");
            }
            sb.Append(VSLocalization.Format(VSLocalization.Str.Bandwidth, aliveEnemies));
            _hudText.text = sb.ToString();
        }

        public void ShowDesync(bool show, uint frame = 0)
        {
            _desyncPanel.SetActive(show);
            if (show)
                _desyncText.text = VSLocalization.Format(VSLocalization.Str.Desync, frame);
        }

        public void ShowPause(bool show, int upgradingSlot = -1)
        {
            _pausePanel.SetActive(show);
            if (show && upgradingSlot >= 0)
                _pauseText.text = VSLocalization.Format(VSLocalization.Str.Paused, upgradingSlot + 1);
        }

        public void ShowUpgrade(bool show) => _upgradePanel.SetActive(show);

        public void UpdateUpgradePanel(ref PlayerState player)
        {
            _upgradeTitle.text = VSLocalization.Format(VSLocalization.Str.LevelUpTitle, player.Level);
            for (int i = 0; i < 4; i++)
            {
                var wt = (WeaponType)(i + 1);
                string icon = WeaponIcons[(int)wt];
                string name = WeaponLocName(wt);
                int s = player.FindWeaponSlot(wt);
                _upgradeBtnTexts[i].text = s >= 0
                    ? VSLocalization.Format(VSLocalization.Str.WeaponUpgrade,
                        i + 1, icon, name,
                        player.GetWeapon(s).Level, player.GetWeapon(s).Level + 1)
                    : VSLocalization.Format(VSLocalization.Str.WeaponNew, i + 1, icon, name);
            }
        }

        // ── Helpers ────────────────────────────────────────────────────────────

        static string WeaponLocName(WeaponType wt)
        {
            int idx = (int)wt - 1;
            return idx >= 0 && idx < WeaponLocKeys.Length
                ? VSLocalization.Get(WeaponLocKeys[idx])
                : "";
        }

        static string BuildWeaponStr(ref PlayerState p)
        {
            var sb = new System.Text.StringBuilder(32);
            for (int i = 0; i < PlayerState.MaxWeaponSlots; i++)
            {
                var w = p.GetWeapon(i);
                if (w.Type == WeaponType.None) continue;
                if (sb.Length > 0) sb.Append(' ');
                sb.Append(WeaponIcons[(int)w.Type]).Append(w.Level);
            }
            return sb.ToString();
        }

        GameObject MakePanel(Transform parent, Color bg,
            Vector2 ancMin, Vector2 ancMax, Vector2 pivot, Vector2 pos, Vector2 size)
        {
            var go = new GameObject("Panel", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            SetRect(go.GetComponent<RectTransform>(), ancMin, ancMax, pivot, pos, size);
            var img = go.AddComponent<Image>();
            img.color = bg;
            img.sprite = WhiteSprite();
            return go;
        }

        Text MakeText(Transform parent, int fontSize, Color color, TextAnchor align)
        {
            var go = new GameObject("Text", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var t = go.AddComponent<Text>();
            t.font = _font;
            t.fontSize = fontSize;
            t.color = color;
            t.alignment = align;
            t.supportRichText = true;
            return t;
        }

        InputField MakeInputField(Transform parent, string placeholder, string defaultVal,
                                   Vector2 pos, Vector2 size)
        {
            var go = new GameObject("InputField", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            SetRect(go.GetComponent<RectTransform>(),
                new Vector2(0, 1), new Vector2(0, 1), new Vector2(0, 1), pos, size);

            var bg = go.AddComponent<Image>();
            bg.color = new Color(0.08f, 0.08f, 0.13f, 1f);
            bg.sprite = WhiteSprite();

            var phGo = new GameObject("Placeholder", typeof(RectTransform));
            phGo.transform.SetParent(go.transform, false);
            FillRect(phGo.GetComponent<RectTransform>(), 6, 4);
            var ph = phGo.AddComponent<Text>();
            ph.font = _font;
            ph.fontSize = 18;
            ph.color = new Color(0.40f, 0.40f, 0.40f, 1f);
            ph.text = placeholder;
            ph.alignment = TextAnchor.MiddleLeft;
            ph.supportRichText = false;

            var txtGo = new GameObject("Text", typeof(RectTransform));
            txtGo.transform.SetParent(go.transform, false);
            FillRect(txtGo.GetComponent<RectTransform>(), 6, 4);
            var txt = txtGo.AddComponent<Text>();
            txt.font = _font;
            txt.fontSize = 18;
            txt.color = Color.white;
            txt.alignment = TextAnchor.MiddleLeft;
            txt.supportRichText = false;

            var field = go.AddComponent<InputField>();
            field.textComponent = txt;
            field.placeholder = ph;
            field.text = defaultVal;
            var cols = field.colors;
            cols.normalColor      = new Color(0.08f, 0.08f, 0.13f, 1f);
            cols.highlightedColor = new Color(0.13f, 0.13f, 0.20f, 1f);
            cols.selectedColor    = new Color(0.16f, 0.16f, 0.24f, 1f);
            field.colors = cols;
            return field;
        }

        Button MakeButton(Transform parent, Vector2 pos, Vector2 size, Action onClick)
        {
            var go = new GameObject("Button", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            SetRect(go.GetComponent<RectTransform>(),
                new Vector2(0, 1), new Vector2(0, 1), new Vector2(0, 1), pos, size);

            var img = go.AddComponent<Image>();
            img.color = new Color(0.15f, 0.15f, 0.25f, 1f);
            img.sprite = WhiteSprite();

            var btn = go.AddComponent<Button>();
            var cols = btn.colors;
            cols.normalColor      = new Color(0.15f, 0.15f, 0.25f, 1f);
            cols.highlightedColor = new Color(0.30f, 0.30f, 0.45f, 1f);
            cols.pressedColor     = new Color(0.08f, 0.08f, 0.15f, 1f);
            btn.colors = cols;
            btn.onClick.AddListener(() => onClick());

            var labelGo = new GameObject("Label", typeof(RectTransform));
            labelGo.transform.SetParent(go.transform, false);
            FillRect(labelGo.GetComponent<RectTransform>(), 8, 0);
            var t = labelGo.AddComponent<Text>();
            t.font = _font;
            t.fontSize = 20;
            t.color = Color.white;
            t.alignment = TextAnchor.MiddleCenter;
            t.fontStyle = FontStyle.Bold;
            return btn;
        }

        static void SetRect(RectTransform rt,
            Vector2 ancMin, Vector2 ancMax, Vector2 pivot, Vector2 pos, Vector2 size)
        {
            rt.anchorMin        = ancMin;
            rt.anchorMax        = ancMax;
            rt.pivot            = pivot;
            rt.anchoredPosition = pos;
            rt.sizeDelta        = size;
        }

        static void FillRect(RectTransform rt, float hPad, float vPad)
        {
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = new Vector2(hPad, vPad);
            rt.offsetMax = new Vector2(-hPad, -vPad);
        }

        static Sprite WhiteSprite()
        {
            var tex = new Texture2D(1, 1);
            tex.SetPixel(0, 0, Color.white);
            tex.Apply();
            return Sprite.Create(tex, new Rect(0, 0, 1, 1), Vector2.one * 0.5f);
        }
    }
}
